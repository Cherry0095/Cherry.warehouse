# Ai Based Ware Housing v1.0 - Point of Sale with Stock Management System

## Designed and Developed by aibasedwarehousing.com

## aibasedwarehousing.com

## Contact 0307 7668212

## Exclusively at superior university
