<?php defined('ENVIRONMENT') OR exit('No direct access allowed!');
return array('username'=>'codiumtech','purchase_code'=>'b991240f-6afa-45b5-a6f4-a3a97fb2a177');