<?php

function image_dimentiaons()
{
	array( 
		'40x40', 
		'66x66',
		'70x80',
		'220x220',
		'225x25',
		'383x383',
		'388x193',
		'450x420',
		'1300x266',
		'1500x62',
	);
}