<?php
// namespace SMSGateway;
include DIR_INCLUDE.'sms/vendor/autoload.php';

class SMSGatewaylib extends SMSGateway\SMSGateway {
}