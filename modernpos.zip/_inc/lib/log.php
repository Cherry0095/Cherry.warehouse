<?php
/*
| -----------------------------------------------------
| PRODUCT NAME: 	Ai Based Ware Housing Ware Housing
| -----------------------------------------------------
| AUTHOR:			aibasedwarehousing.com
| -----------------------------------------------------
| EMAIL:			info@aibasedwarehousing.com
| -----------------------------------------------------
| COPYRIGHT:		RESERVED BY aibasedwarehousing.com
| -----------------------------------------------------
| WEBSITE:			http://aibasedwarehousing.com
| -----------------------------------------------------
*/
class Log 
{
	private $handle;
	
	public function __construct($filename) {
		if (LOG) {
			$this->handle = fopen(DIR_LOG . $filename, 'a');
		}
	}
	
	public function write($message) {
		if (LOG) {
			if (!$message) return;
			fwrite($this->handle, date('Y-m-d G:i:s') . ' - ' . print_r($message, true) . "\n");
		}
	}

	public function simplyWrite($message) {
		if (LOG) {
			if (!$message) return;
			fwrite($this->handle, print_r($message, true) . "\n");
		}
	}
	
	public function __destruct() {
		if (LOG) {
			fclose($this->handle);
		}
	}
}