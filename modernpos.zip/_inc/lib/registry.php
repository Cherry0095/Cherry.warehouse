<?php
/*
| -----------------------------------------------------
| PRODUCT NAME: 	Ai Based Ware Housing Ware Housing
| -----------------------------------------------------
| AUTHOR:			aibasedwarehousing.com
| -----------------------------------------------------
| EMAIL:			info@aibasedwarehousing.com
| -----------------------------------------------------
| COPYRIGHT:		RESERVED BY aibasedwarehousing.com
| -----------------------------------------------------
| WEBSITE:			http://aibasedwarehousing.com
| -----------------------------------------------------
*/
final class Registry 
{
	private $data = array();

	public function get($key) 
	{
		return (isset($this->data[$key]) ? $this->data[$key] : null);
	}

	public function set($key, $value) 
	{
		$this->data[$key] = $value;
	}

	public function has($key) 
	{
		return isset($this->data[$key]);
	}
}