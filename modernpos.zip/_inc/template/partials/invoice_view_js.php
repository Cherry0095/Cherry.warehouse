<div class="table-responsive">
<div id="invoice" class="row">
   <div class="col-xs-12 col-md-12">  
		<?php include('invoice_view.php'); ?>
	</div>
</div>
</div>