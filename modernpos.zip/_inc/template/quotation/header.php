<!DOCTYPE html>
<html>
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
	<title>Quotation</title>
	<!-- <link type="text/css" href="<?php echo root_url();?>/assets/bootstrap/css/bootstrap.css" type="text/css" rel="stylesheet"> -->
	<link type="text/css" href="<?php echo root_url();?>/assets/aibasedwarehousing/cssmin/main.css" type="text/css" rel="stylesheet">

<style type="text/css">
table td {
	padding: 5px;
}
</style>
</head>
<body>