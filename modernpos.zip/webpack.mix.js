const mix = require('laravel-mix');

// // Main CSS
// mix.styles([

//     // Plugins
//     'assets/bootstrap/css/bootstrap.css',
//     'assets/jquery-ui/jquery-ui.min.css',
//     'assets/font-awesome/css/font-awesome.css',
//     'assets/morris/morris.css',
//     'assets/select2/select2.min.css',
//     'assets/datepicker/datepicker3.css',
//     'assets/timepicker/bootstrap-timepicker.css',
//     'assets/bootstrap-wysihtml5/bootstrap3-wysihtml5.min.css',
//     'assets/perfectScroll/css/perfect-scrollbar.css',
//     'assets/toastr/toastr.min.css',

//     // Filemanager
//     'assets/aibasedwarehousing/css/filemanager/dialogs.css',
//     'assets/aibasedwarehousing/css/filemanager/main.css',

//     // Theme
//     'assets/aibasedwarehousing/css/theme.css',
//     'assets/aibasedwarehousing/css/skins/skin-black.css',
//     'assets/aibasedwarehousing/css/skins/skin-blue.css',
//     'assets/aibasedwarehousing/css/skins/skin-green.css',
//     'assets/aibasedwarehousing/css/skins/skin-red.css',
//     'assets/aibasedwarehousing/css/skins/skin-yellow.css',

//     // DataTable
//     'assets/DataTables/datatables.min.css',

//     // Main CSS
//     'assets/aibasedwarehousing/css/main.css',

//     // Responsive CSS
//     'assets/aibasedwarehousing/css/responsive.css',

//     // Barcode CSS
//     // 'assets/aibasedwarehousing/css/barcode.css',

//     // Print CSS
//     'assets/aibasedwarehousing/css/print.css',

// ],'assets/aibasedwarehousing/cssmin/main.css');



// // Main RTL CSS
// mix.styles([

//     // Plugins
//     'assets/bootstrap/css/bootstrap-rtl.css',
//     'assets/jquery-ui/jquery-ui.min.css',
//     'assets/font-awesome/css/font-awesome.css',
//     'assets/morris/morris.css',
//     'assets/select2/select2.min.css',
//     'assets/datepicker/datepicker3.css',
//     'assets/timepicker/bootstrap-timepicker.css',
//     'assets/bootstrap-wysihtml5/bootstrap3-wysihtml5.min.css',
//     'assets/perfectScroll/css/perfect-scrollbar.css',
//     'assets/toastr/toastr.min.css',

//     // Filemanager
//     'assets/aibasedwarehousing/css/filemanager/dialogs.css',
//     'assets/aibasedwarehousing/css/filemanager/main.css',

//     // Theme
//     'assets/aibasedwarehousing/css/theme.css',
//     'assets/aibasedwarehousing/css/skins/skin-black.css',
//     'assets/aibasedwarehousing/css/skins/skin-blue.css',
//     'assets/aibasedwarehousing/css/skins/skin-green.css',
//     'assets/aibasedwarehousing/css/skins/skin-red.css',
//     'assets/aibasedwarehousing/css/skins/skin-yellow.css',

//     // DataTable
//     'assets/DataTables/datatables.min.css',

//     // Main CSS
//     'assets/aibasedwarehousing/css/main.css',

//     // Responsive CSS
//     'assets/aibasedwarehousing/css/responsive.css',

//     // Barcode CSS
//     // 'assets/aibasedwarehousing/css/barcode.css',

//     // Print CSS
//     'assets/aibasedwarehousing/css/print.css',

//     // RTL
//     'assets/aibasedwarehousing/css/rtl.css',

// ],'assets/aibasedwarehousing/cssmin/main-rtl.css');



// // POS CSS
// mix.styles([

//     'assets/bootstrap/css/bootstrap.css',
//     'assets/jquery-ui/jquery-ui.min.css',
//     'assets/font-awesome/css/font-awesome.css',
//     'assets/datepicker/datepicker3.css',
//     'assets/timepicker/bootstrap-timepicker.min.css',
//     'assets/perfectScroll/css/perfect-scrollbar.css',
//     'assets/select2/select2.min.css',
//     'assets/toastr/toastr.min.css',
//     'assets/contextMenu/dist/jquery.contextMenu.min.css',

//     // Filemanager
//     'assets/aibasedwarehousing/css/filemanager/dialogs.css',
//     'assets/aibasedwarehousing/css/filemanager/main.css',

//     // Theme
//     'assets/aibasedwarehousing/css/theme.css',
//     'assets/aibasedwarehousing/css/skins/skin-black.css',
//     'assets/aibasedwarehousing/css/skins/skin-blue.css',
//     'assets/aibasedwarehousing/css/skins/skin-green.css',
//     'assets/aibasedwarehousing/css/skins/skin-red.css',
//     'assets/aibasedwarehousing/css/skins/skin-yellow.css',

//     // Main
//     'assets/aibasedwarehousing/css/main.css',

//     // POS
//     'assets/aibasedwarehousing/css/pos/skeleton.css',
//     'assets/aibasedwarehousing/css/pos/pos.css',
//     'assets/aibasedwarehousing/css/pos/responsive.css',

// ],'assets/aibasedwarehousing/cssmin/pos.css');



// // POS RTL CSS
// mix.styles([

//     'assets/bootstrap/css/bootstrap-rtl.css',
//     'assets/jquery-ui/jquery-ui.min.css',
//     'assets/font-awesome/css/font-awesome.css',
//     'assets/datepicker/datepicker3.css',
//     'assets/timepicker/bootstrap-timepicker.min.css',
//     'assets/perfectScroll/css/perfect-scrollbar.css',
//     'assets/select2/select2.min.css',
//     'assets/toastr/toastr.min.css',
//     'assets/contextMenu/dist/jquery.contextMenu.min.css',

//     // Filemanager
//     'assets/aibasedwarehousing/css/filemanager/dialogs.css',
//     'assets/aibasedwarehousing/css/filemanager/main.css',

//     // Theme
//     'assets/aibasedwarehousing/css/theme.css',
//     'assets/aibasedwarehousing/css/skins/skin-black.css',
//     'assets/aibasedwarehousing/css/skins/skin-blue.css',
//     'assets/aibasedwarehousing/css/skins/skin-green.css',
//     'assets/aibasedwarehousing/css/skins/skin-red.css',
//     'assets/aibasedwarehousing/css/skins/skin-yellow.css',

//     // Main
//     'assets/aibasedwarehousing/css/main.css',

//     // POS
//     'assets/aibasedwarehousing/css/pos/skeleton.css',
//     'assets/aibasedwarehousing/css/pos/pos.css',
//     'assets/aibasedwarehousing/css/pos/responsive.css',

//     // RTL
//     'assets/aibasedwarehousing/css/rtl.css',

// ],'assets/aibasedwarehousing/cssmin/pos-rtl.css');



// // LOGIN CSS
// mix.styles([

//     'assets/bootstrap/css/bootstrap.css',
//     'assets/perfectScroll/css/perfect-scrollbar.css',
//     'assets/toastr/toastr.min.css',
//     'assets/aibasedwarehousing/css/theme.css',
//     'assets/aibasedwarehousing/css/login.css',

// ],'assets/aibasedwarehousing/cssmin/login.css');



// Angular JS
mix.scripts([

    'assets/aibasedwarehousing/angular/lib/angular/angular.min.js',
    'assets/aibasedwarehousing/angular/lib/angular/angular-sanitize.js',
    'assets/aibasedwarehousing/angular/lib/angular/angular-bind-html-compile.min.js',
    'assets/aibasedwarehousing/angular/lib/angular/ui-bootstrap-tpls-2.5.0.min.js',
    'assets/aibasedwarehousing/angular/lib/angular/angular-route.min.js',
    'assets/aibasedwarehousing/angular/lib/angular-translate/dist/angular-translate.min.js',
    'assets/aibasedwarehousing/angular/lib/ng-file-upload/dist/ng-file-upload.min.js',
    'assets/aibasedwarehousing/angular/lib/angular-local-storage.min.js',
    'assets/aibasedwarehousing/angular/angularApp.js',
    
],'assets/aibasedwarehousing/angularmin/angular.js');

// Angular Filemanager JS
mix.scripts([

    'assets/aibasedwarehousing/angular/filemanager/js/directives/directives.js',
    'assets/aibasedwarehousing/angular/filemanager/js/filters/filters.js',
    'assets/aibasedwarehousing/angular/filemanager/js/providers/config.js',
    'assets/aibasedwarehousing/angular/filemanager/js/entities/chmod.js',
    'assets/aibasedwarehousing/angular/filemanager/js/entities/item.js',
    'assets/aibasedwarehousing/angular/filemanager/js/services/apihandler.js',
    'assets/aibasedwarehousing/angular/filemanager/js/services/apimiddleware.js',
    'assets/aibasedwarehousing/angular/filemanager/js/services/filenavigator.js',
    'assets/aibasedwarehousing/angular/filemanager/js/providers/translations.js',
    'assets/aibasedwarehousing/angular/filemanager/js/controllers/main.js',
    'assets/aibasedwarehousing/angular/filemanager/js/controllers/selector-controller.js',

],'assets/aibasedwarehousing/angularmin/filemanager.js');



// Angular Modal JS
mix.scripts([

    'assets/aibasedwarehousing/angular/modals/InvoiceViewModal.js',
    'assets/aibasedwarehousing/angular/modals/InvoiceInfoEditModal.js',
    'assets/aibasedwarehousing/angular/modals/BoxCreateModal.js',
    'assets/aibasedwarehousing/angular/modals/BoxDeleteModal.js',
    'assets/aibasedwarehousing/angular/modals/BoxEditModal.js',
    'assets/aibasedwarehousing/angular/modals/UnitCreateModal.js',
    'assets/aibasedwarehousing/angular/modals/UnitDeleteModal.js',
    'assets/aibasedwarehousing/angular/modals/UnitEditModal.js',
    'assets/aibasedwarehousing/angular/modals/TaxrateCreateModal.js',
    'assets/aibasedwarehousing/angular/modals/TaxrateDeleteModal.js',
    'assets/aibasedwarehousing/angular/modals/TaxrateEditModal.js',
    'assets/aibasedwarehousing/angular/modals/CategoryCreateModal.js',
    'assets/aibasedwarehousing/angular/modals/CategoryDeleteModal.js',
    'assets/aibasedwarehousing/angular/modals/CategoryEditModal.js',
    'assets/aibasedwarehousing/angular/modals/CurrencyEditModal.js',
    'assets/aibasedwarehousing/angular/modals/CustomerCreateModal.js',
    'assets/aibasedwarehousing/angular/modals/CustomerDeleteModal.js',
    'assets/aibasedwarehousing/angular/modals/CustomerEditModal.js',
    'assets/aibasedwarehousing/angular/modals/SupportDeskModal.js',
    'assets/aibasedwarehousing/angular/modals/DueCollectionDetailsModal.js',
    'assets/aibasedwarehousing/angular/modals/BankingDepositModal.js',
    'assets/aibasedwarehousing/angular/modals/BankingRowViewModal.js',
    'assets/aibasedwarehousing/angular/modals/BankingWithdrawModal.js',
    'assets/aibasedwarehousing/angular/modals/BankAccountCreateModal.js',
    'assets/aibasedwarehousing/angular/modals/BankAccountDeleteModal.js',
    'assets/aibasedwarehousing/angular/modals/BankAccountEditModal.js',
    'assets/aibasedwarehousing/angular/modals/BankTransferModal.js',
    'assets/aibasedwarehousing/angular/modals/EmailModal.js',
    'assets/aibasedwarehousing/angular/modals/KeyboardShortcutModal.js',
    'assets/aibasedwarehousing/angular/modals/PmethodDeleteModal.js',
    'assets/aibasedwarehousing/angular/modals/PmethodEditModal.js',
    'assets/aibasedwarehousing/angular/modals/PayNowModal.js',
    'assets/aibasedwarehousing/angular/modals/POSFilemanagerModal.js',
    'assets/aibasedwarehousing/angular/modals/POSReceiptTemplateEditModal.js',
    'assets/aibasedwarehousing/angular/modals/PrinterDeleteModal.js',
    'assets/aibasedwarehousing/angular/modals/PrinterEditModal.js',
    'assets/aibasedwarehousing/angular/modals/PrintReceiptModal.js',
    'assets/aibasedwarehousing/angular/modals/ProductCreateModal.js',
    'assets/aibasedwarehousing/angular/modals/ProductDeleteModal.js',
    'assets/aibasedwarehousing/angular/modals/ProductEditModal.js',
    'assets/aibasedwarehousing/angular/modals/ProductReturnModal.js',
    'assets/aibasedwarehousing/angular/modals/ProductViewModal.js',
    'assets/aibasedwarehousing/angular/modals/StoreDeleteModal.js',
    'assets/aibasedwarehousing/angular/modals/SupplierCreateModal.js',
    'assets/aibasedwarehousing/angular/modals/SupplierDeleteModal.js',
    'assets/aibasedwarehousing/angular/modals/SupplierEditModal.js',
    'assets/aibasedwarehousing/angular/modals/BrandCreateModal.js',
    'assets/aibasedwarehousing/angular/modals/BrandDeleteModal.js',
    'assets/aibasedwarehousing/angular/modals/BrandEditModal.js',
    'assets/aibasedwarehousing/angular/modals/UserCreateModal.js',
    'assets/aibasedwarehousing/angular/modals/UserDeleteModal.js',
    'assets/aibasedwarehousing/angular/modals/UserEditModal.js',
    'assets/aibasedwarehousing/angular/modals/UserGroupCreateModal.js',
    'assets/aibasedwarehousing/angular/modals/UserGroupDeleteModal.js',
    'assets/aibasedwarehousing/angular/modals/UserGroupEditModal.js',
    'assets/aibasedwarehousing/angular/modals/UserInvoiceDetailsModal.js',
    'assets/aibasedwarehousing/angular/modals/GiftcardCreateModal.js',
    'assets/aibasedwarehousing/angular/modals/GiftcardEditModal.js',
    'assets/aibasedwarehousing/angular/modals/GiftcardViewModal.js',
    'assets/aibasedwarehousing/angular/modals/GiftcardTopupModal.js',
    'assets/aibasedwarehousing/angular/modals/InvoiceSMSModal.js',
    'assets/aibasedwarehousing/angular/modals/PaymentFormModal.js',
    'assets/aibasedwarehousing/angular/modals/PaymentOnlyModal.js',
    'assets/aibasedwarehousing/angular/modals/PurchaseInvoiceViewModal.js',
    'assets/aibasedwarehousing/angular/modals/PurchaseInvoiceInfoEditModal.js',
    'assets/aibasedwarehousing/angular/modals/PurchasePaymentModal.js',
    'assets/aibasedwarehousing/angular/modals/SellReturnModal.js',
    'assets/aibasedwarehousing/angular/modals/PurchaseReturnModal.js',
    'assets/aibasedwarehousing/angular/modals/ExpenseSummaryModal.js',
    'assets/aibasedwarehousing/angular/modals/SummaryReportModal.js',
    
],'assets/aibasedwarehousing/angularmin/modal.js');



// Main JS
mix.scripts([

    'assets/jquery/jquery.min.js',
    'assets/jquery-ui/jquery-ui.min.js',
    'assets/bootstrap/js/bootstrap.min.js',
    'assets/chartjs/Chart.min.js',
    'assets/sparkline/jquery.sparkline.min.js',
    'assets/datepicker/bootstrap-datepicker.js',
    'assets/timepicker/bootstrap-timepicker.min.js',
    'assets/bootstrap-wysihtml5/bootstrap3-wysihtml5.all.min.js',
    'assets/select2/select2.min.js',
    'assets/perfectScroll/js/perfect-scrollbar.jquery.min.js',
    'assets/sweetalert/sweetalert.min.js',
    'assets/toastr/toastr.min.js',
    'assets/accounting/accounting.min.js',
    'assets/underscore/underscore.min.js',
    'assets/aibasedwarehousing/js/ie.js',
    'assets/aibasedwarehousing/js/theme.js',
    'assets/aibasedwarehousing/js/common.js',
    'assets/aibasedwarehousing/js/main.js',
    'assets/DataTables/datatables.min.js',
    'assets/aibasedwarehousing/angularmin/angular.js',
    'assets/aibasedwarehousing/angularmin/modal.js',
    'assets/aibasedwarehousing/angularmin/filemanager.js',

],'assets/aibasedwarehousing/jsmin/main.js');



// POS JS
mix.scripts([

    'assets/jquery/jquery.min.js',
    'assets/jquery-ui/jquery-ui.min.js',
    'assets/bootstrap/js/bootstrap.min.js',
    'assets/aibasedwarehousing/angularmin/angular.js',
    'assets/aibasedwarehousing/angular/angularApp.js',
    'assets/aibasedwarehousing/angularmin/filemanager.js',
    'assets/aibasedwarehousing/angularmin/modal.js',

    'assets/datepicker/bootstrap-datepicker.js',
    'assets/timepicker/bootstrap-timepicker.min.js',
    'assets/select2/select2.min.js',
    'assets/perfectScroll/js/perfect-scrollbar.jquery.min.js',
    'assets/sweetalert/sweetalert.min.js',
    'assets/toastr/toastr.min.js',
    'assets/accounting/accounting.min.js',
    'assets/underscore/underscore.min.js',
    'assets/contextMenu/dist/jquery.contextMenu.min.js',
    'assets/aibasedwarehousing/js/ie.js',

    'assets/aibasedwarehousing/js/common.js',
    'assets/aibasedwarehousing/js/main.js',
    'assets/aibasedwarehousing/js/pos/pos.js',

],'assets/aibasedwarehousing/jsmin/pos.js');


// LOGIN JS
mix.scripts([

    'assets/jquery/jquery.min.js',
    'assets/bootstrap/js/bootstrap.min.js',
    'assets/perfectScroll/js/perfect-scrollbar.jquery.min.js',
    'assets/toastr/toastr.min.js',
    'assets/aibasedwarehousing/js/forgot-password.js',
    'assets/aibasedwarehousing/js/common.js',
    'assets/aibasedwarehousing/js/login.js',

],'assets/aibasedwarehousing/jsmin/login.js');



// How to build assets
// npm run dev
// npm run production